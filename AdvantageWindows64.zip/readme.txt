Welcome to modernized global peer-to-peer transacting

to successfully connect to the Blockchain, please follow the steps below:

open your wallet for the first time and set a secure password
encrypt your wallet in settings, once complete close the wallet
press windows key, found on bottom of keyboard
type %appdata%, press enter
double-click Advantage
right-click, edit - Advantage.conf using notepad or any text editor
fill in the following information to be successfully connected:

Create a private username and password, these are important:

server=1
rpcuser=yourusername
rpcpassword=yourpassword
